# analyse.py

To analyse `numbers.csv`, with outputs stored to `results.txt`, run:

    python analyse.py numbers.csv > results.txt

You will need Python 2 to run `analyse.py`.
