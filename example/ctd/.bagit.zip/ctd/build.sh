#!/bin/sh

set -e

bag_dir=ro-bag

bagit () {
    cd ${bag_dir}
    md5sum data/* > manifest-md5.txt
    sha1sum data/* > manifest-sha1.txt
    find metadata -type f | xargs md5sum > tagmanifest-md5.txt
    find metadata -type f | xargs sha1sum > tagmanifest-sha1.txt
    cd ..
    archive=${bag_dir}.bagit.zip
    rm -f ${archive}
    zip -q -r ${archive} ${bag_dir}
    echo Built BagIt ${archive}
}
bundle_ro () {
    bundle=${bag_dir}.bundle.zip
    rm -f ${bundle}
    cd ${bag_dir}
    echo -n application/vnd.wf4ever.robundle+zip > mimetype
    mv metadata .ro
    zip -q -0 -X ../${bundle} mimetype
    mv .ro metadata
    rm mimetype
    zip -q -r ../${bundle} .
    echo Built RO Bundle ${bundle}
    cd ..
}
bagit $*
